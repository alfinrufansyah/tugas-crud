<?php
$dbHost = "localhost"; // Ganti dengan host database Anda
$dbUser = "root"; // Ganti dengan username database Anda
$dbPass = ""; // Ganti dengan password database Anda
$dbName = "crud"; // Ganti dengan nama database Anda

$koneksi = mysqli_connect($dbHost, $dbUser, $dbPass, $dbName);

if (!$koneksi) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
